


import zmq
import time

context = zmq.Context()
socket = context.socket(zmq.PUB)

# Bind to localhost
socket.bind("tcp://127.0.0.1:5555")

while True:
    # Send a string message
    message = "Hello, this is the server"
    socket.send_string(message)

    print(f"Sent: {message}")
    time.sleep(1)
