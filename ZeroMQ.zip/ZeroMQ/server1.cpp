//  Hello World server
#include <zmqpp/zmqpp.hpp>
#include <string>
#include <iostream>
#include <chrono>
#include <thread>
#include <nlohmann/json.hpp>

using namespace std;

int main(int argc, char *argv[]) {
  const string endpoint = "tcp://127.0.0.1:5556";

  // initialize the 0MQ context
  zmqpp::context context;

  // generate a reply socket
  zmqpp::socket_type type = zmqpp::socket_type::reply;
  zmqpp::socket socket (context, type);

  // bind to the socket
  socket.bind(endpoint);
  
  while (1) {
    // receive the message
    zmqpp::message incoming;
    socket.receive(incoming);

    // Prepare data
    int robot_2_PosX = 200, robot_2_PosY = 100, robot_2_strategy = 1;
    

    nlohmann::json j;
    j["a"] = robot_2_PosX;
    j["b"] = robot_2_PosY;
    j["c"] = robot_2_strategy;
    // j["d"] = ball_x;
    // j["z"] = ball_y;
    string message = j.dump();

    // send reply
    zmqpp::message reply;
    reply << message;
    socket.send(reply);

    cout << "Sent: " << message << endl;

    //Do some 'work'
    std::this_thread::sleep_for(std::chrono::seconds(1));
  }

  return 0;
}

// #include <zmqpp/zmqpp.hpp>
// #include <zmq.h>

// #include <string>
// #include <iostream>
// #include <chrono>
// #include <thread>

// using namespace std;

// int main(int argc, char *argv[]) {
//   const string endpoint = "tcp://127.0.0.1:5555";

//   // initialize the 0MQ context
//   zmqpp::context context;

//   // generate a pull socket
//   zmqpp::socket_type type = zmqpp::socket_type::reply;
//   zmqpp::socket socket (context, type);

//   // bind to the socket
//   socket.bind(endpoint);
//   while (1) {
//     // receive the message
//     zmqpp::message message;
//     // decompose the message 
//     // socket.receive(message);
//     // string text;
//     // message >> text;
//     double a = 1.234;
//     float b = 5.678f;
//     int c = 9;
//     string d = "Hello";
//     bool z = true;

//     nlohmann::json j;
//         j["a"] = a;
//         j["b"] = b;
//         j["c"] = c;
//         j["d"] = d;
//         j["z"] = z;
//     string message = j.dump();
//     zmq::message_t zmq_message(message.begin(), message.end());
//     socket.send(zmq_message, zmq::send_flags::none);

//     cout << "Sent: " << message << endl;
//     //Do some 'work'
//     std::this_thread::sleep_for(std::chrono::seconds(1));
//     // cout << "Received Hello" << endl;
//     // socket.send("World");
//   }

// }

// #include <zmq.hpp>
// #include <string>
// #include <iostream>
// #include <unistd.h>

// int main() {
//     //  Prepare our context and publisher
//     zmq::context_t context(1);
//     zmq::socket_t publisher(context, ZMQ_PUB);
//     publisher.bind("tcp://127.0.0.1:5556");

//     while (true) {
//         // Create a string message
//         std::string message = "Hello, this is the server";

//         // Send the message
//         zmq::message_t zmq_message(message.begin(), message.end());
//         publisher.send(zmq_message, zmq::send_flags::none);

//         std::cout << "Sent: " << message << std::endl;

//         // Sleep for a second
//         sleep(1);
//     }

//     return 0;
// }

