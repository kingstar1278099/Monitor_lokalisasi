#
#   Hello World client in Python
#   Connects REQ socket to tcp://localhost:5555
#   Sends "Hello" to server, expects "World" back
#

import zmq
import json  # <- Add this line

context = zmq.Context()

# Socket to talk to server
print("Connecting to hello world server…")
socket = context.socket(zmq.REQ)
socket.connect("tcp://127.0.0.1:5555")

# Do requests, waiting each time for a response
while True:
    socket.send_string("Request")  # <- Add this line

    # Get the reply.
    message = socket.recv_string()
    # Deserialize the data
    data = json.loads(message)

    # Print the data
    print("Received: ", data)

    # Access specific variables
    a = data['a']
    b = data['b']
    c = data['c']
    d = data['d']
    z = data['z']
    print("a: ", type(a), " b: ", type(b), " c: ", type(c), " d: ", type(d), " z: ", type(z))


# import zmq

# context = zmq.Context()

# # Create a SUB socket
# socket = context.socket(zmq.SUB)

# # Connect to the publisher at localhost
# socket.connect("tcp://127.0.0.1:5556")

# # Subscribe to all topics
# socket.setsockopt_string(zmq.SUBSCRIBE, '')

# while True:
#     # Receive a message
#     message = socket.recv_string()

#     # Print the message
#     print("Received: ", message)
