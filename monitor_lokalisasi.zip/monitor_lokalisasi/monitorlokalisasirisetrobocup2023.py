import cv2
import numpy as np
import zmq
import json

robot_1_PosX, robot_1_PosY = 0,  0
robot_2_PosX, robot_2_PosY = 0,  0
robot_3_PosX, robot_3_PosY = 0,  0
robot_4_PosX, robot_4_PosY = 0,  0
robot_5_PosX, robot_5_PosY = 0,  0
robot_1_strategy = 0
robot_2_strategy = 0
robot_3_strategy = 0
robot_4_strategy = 0
robot_5_strategy = 0

found_ball_1 = -1
found_ball_2 = -1
found_ball_3 = -1
found_ball_4 = -1
ball_coor_x = 0
ball_coor_y = 0
pickup_1 = pickup_2 = pickup_3 = pickup_4 = False
play_1 = play_2 = play_3 = play_4 =False
yaw_1 = yaw_2 = yaw_3 = yaw_4 = 0
strategy_1 = strategy_2 = strategy_3 = strategy_4 = 0
role_1 = role_2 = role_3 = role_4 = 0
# Define your own robot positions and strategies
ball_x, ball_y, ball_x_1, ball_y_1, ball_x_2, ball_y_2, ball_x_3, ball_y_3, ball_x_4, ball_y_4 = 0,0,0,0,0,0,0,0,0,0
mapImage = np.zeros((800,1100,3), np.uint8)
robotInitialPosition = np.zeros((3))
context = zmq.Context()

# # Socket to talk to server
print("Connecting to hello world server…")
# socket = context.socket(zmq.REQ)
# socket.connect("tcp://192.168.5.101:5555")
# socket1 = context.socket(zmq.REQ)
# socket1.connect("tcp://192.168.5.102:5555")
socket2 = context.socket(zmq.REQ)
socket2.connect("tcp://192.168.5.103:5555")
# socket3 = context.socket(zmq.REQ)
# socket3.connect("tcp://192.168.5.104:5555")

#local
# socket = context.socket(zmq.REQ)
# socket.connect("tcp://127.0.0.1:5555")
# socket1 = context.socket(zmq.REQ)
# socket1.connect("tcp://127.0.0.1:5556")
# socket2 = context.socket(zmq.REQ)
# socket2.connect("tcp://127.0.0.1:5557")
# socket3 = context.socket(zmq.REQ)
# socket3.connect("tcp://127.0.0.1:5558")
# Your worldCoorToImageCoor function
def worldCoorToImageCoor(x, y):		
    x = x				
    y = y		
    return int(x), int(y)

def main():
    global robot_1_PosX, robot_1_PosY
    global robot_2_PosX, robot_2_PosY
    global robot_3_PosX, robot_3_PosY
    global robot_4_PosX, robot_4_PosY
    global robot_5_PosX, robot_5_PosY
    global robot_1_strategy, robot_2_strategy, robot_3_strategy, robot_4_strategy, robot_5_strategy
    global ball_x, ball_y, ball_x_1, ball_y_1, ball_x_2, ball_y_2, ball_x_3, ball_y_3, ball_x_4, ball_y_4
    global found_ball_1 ,found_ball_2 ,found_ball_3 ,found_ball_4 
    global ball_coor_x,ball_coor_y
    global pickup_1 , pickup_2 , pickup_3 , pickup_4 
    global play_1 , play_2 , play_3 , play_4 
    global yaw_1 , yaw_2 , yaw_3 , yaw_4
    global strategy_1 , strategy_2 , strategy_3 , strategy_4
    global role_1 , role_2 , role_3 , role_4
    while True:
        
        # socket.send_string("Request")
        # message = socket.recv_string()
        # # Deserialize the data
        # data = json.loads(message)
        # robot_1_PosX = data['a']
        # robot_1_PosY = data['b']
        # found_ball_1 = int(data['c'])
        # ball_x_1 = int(data['d'])
        # pickup_1 = data['e']
        # play_1   = data['f']
        # yaw_1    = data['g']
        # strategy_1 = data['h']
        # role_1     = data['i']
        # ball_y_1 = int(data['z'])
        # # Print the data
        # print("Received Robot 1: ", data)

        # socket1.send_string("Request")
        # message1 = socket1.recv_string()
        # # Deserialize the data
        # data1 = json.loads(message1)
        # robot_2_PosX = data1['a']
        # robot_2_PosY = data1['b']
        # found_ball_2 = int(data1['c'])
        # ball_x_2 = int(data1['d'])
        # pickup_2 = data1['e']
        # play_2   = data1['f']
        # yaw_2    = data1['g']
        # strategy_2 = data1['h']
        # role_2     = data1['i']
        # ball_y_2 = int(data1['z'])
        # # Print the data
        # print("Received Robot 2: ", data1)

        socket2.send_string("Request")
        message2 = socket2.recv_string()
        # Deserialize the data
        data2 = json.loads(message2)
        robot_3_PosX = data2['a']
        robot_3_PosY = data2['b']
        found_ball_3 = int(data2['c'])
        ball_x_3 = int(data2['d'])
        pickup_3 = data2['e']
        play_3   = data2['f']
        yaw_3    = data2['g']
        strategy_3 = data2['h']
        role_3     = data2['i']
        ball_y_3 = int(data2['z'])
        # Print the data
        print("Received Robot 3: ", data2)
        # sssr

        # socket3.send_string("Request")
        # message3 = socket3.recv_string()
        # # Deserialize the data
        # data3 = json.loads(message3)
        # robot_4_PosX = data3['a']
        # robot_4_PosY = data3['b']
        # found_ball_4 = int(data3['c'])
        # ball_x_4 = int(data3['d'])
        # pickup_4 = data3['e']
        # play_4   = data3['f']
        # yaw_4    = data3['g']
        # strategy_4 = data3['h']
        # role_4     = data3['i']
        # ball_y_4 = int(data3['z'])
        # # Print the data
        # print("Received Robot 4: ", data3)
        
        # Data
        data_robot = {}

        if found_ball_1 != 999:
            data_robot["Robot1"] = {"Jarak": found_ball_1, "ball_x": ball_x_1, "ball_y": ball_y_1}

        if found_ball_2 != 0:
            data_robot["Robot2"] = {"Jarak": found_ball_2, "ball_x": ball_x_2, "ball_y": ball_y_2}

        if found_ball_3 != 0:
            data_robot["Robot3"] = {"Jarak": found_ball_3, "ball_x": ball_x_3, "ball_y": ball_y_3}

        if found_ball_4 != 0:
            data_robot["Robot4"] = {"Jarak": found_ball_4, "ball_x": ball_x_4, "ball_y": ball_y_4}

        # Mencari robot dengan jarak terdekat jika data_robot tidak kosong
        if data_robot:
            nama_robot_terdekat = min(data_robot, key=lambda x: data_robot[x]["Jarak"])

            # Mengambil data ball_x dan ball_y dari robot terdekat
            ball_x = data_robot[nama_robot_terdekat]["ball_x"]
            ball_y = data_robot[nama_robot_terdekat]["ball_y"]

            print(f"Robot dengan jarak terdekat adalah {nama_robot_terdekat} dengan jarak {data_robot[nama_robot_terdekat]['Jarak']}")
            print(f"Data ball_x: {ball_x}, Data ball_y: {ball_y}") 
        else:
            print("Semua robot tidak mendeteksi bola.")

        # data_robot = {
        #     "Robot1": {"Jarak": found_ball_1, "ball_x": ball_x_1, "ball_y": ball_y_1},
        #     "Robot2": {"Jarak": found_ball_2, "ball_x": ball_x_2, "ball_y": ball_y_2},
        #     "Robot3": {"Jarak": found_ball_3, "ball_x": ball_x_3, "ball_y": ball_y_3},
        #     "Robot4": {"Jarak": found_ball_4, "ball_x": ball_x_4, "ball_y": ball_y_4},
        # }

        # nama_robot_terdekat = min(data_robot, key=lambda x: data_robot[x]["Jarak"])

        # # Mengambil data ball_x dan ball_y dari robot terdekat
        # ball_x = data_robot[nama_robot_terdekat]["ball_x"]
        # ball_y = data_robot[nama_robot_terdekat]["ball_y"]

        # print(f"Robot dengan jarak terdekat adalah {nama_robot_terdekat} dengan jarak {data_robot[nama_robot_terdekat]['Jarak']}")
        # print(f"Data ball_x: {ball_x}, Data ball_y: {ball_y}")  

        mapImage[:] = (0, 255, 0)
        cv2.rectangle(mapImage, (100,100), (1000,700), (255,255,255), 3) #. Garis Luar
        cv2.rectangle(mapImage, (40,530), (100,270),(255,255,255), 3) # Garis Luar Gawang Kiri
        cv2.rectangle(mapImage, (1000,530), (1060,270), (255,255,255), 3) # Garis Luar Gawang Kiri
        cv2.rectangle(mapImage, (100,650), (300,150), (255,255,255), 3) # Garis Luar Gawang Kiri
        cv2.rectangle(mapImage, (1000,650), (800,150), (255,255,255), 3) # Garis Luar Gawang Kiri
        cv2.rectangle(mapImage, (100,550), (200,250), (255,255,255), 3) # Garis Luar Gawang Kiri
        cv2.rectangle(mapImage, (1000,550), (900,250), (255,255,255), 3) # Garis Luar Gawang Kiri
        cv2.line(mapImage, (550,100), (550,700), (255,255,255), 3) # Garis Tengah
        cv2.circle(mapImage, (550,400), 75, (255,255,255), 3) # Lingkaran Tengah
        cv2.circle(mapImage, (250,400), 3, (255,255,255), 5) #titik Pinalti
        cv2.circle(mapImage, (850,400), 3, (255,255,255), 5) #titik Pinalti Lawan
        cv2.line(mapImage, (100,200), (1000,200), (0,0,0), 1)
        cv2.line(mapImage, (100,300), (1000,300), (0,0,0), 1)
        cv2.line(mapImage, (100,400), (1000,400), (0,0,0), 1)
        cv2.line(mapImage, (100,500), (1000,500), (0,0,0), 1)
        cv2.line(mapImage, (100,600), (1000,600), (0,0,0), 1)
                            
        cv2.line(mapImage, (200,100), (200,700), (0,0,0), 1)
        cv2.line(mapImage, (300,100), (300,700), (0,0,0), 1)
        cv2.line(mapImage, (400,100), (400,700), (0,0,0), 1)
        cv2.line(mapImage, (500,100), (500,700), (0,0,0), 1)
        cv2.line(mapImage, (600,100), (600,700), (0,0,0), 1)
        cv2.line(mapImage, (700,100), (700,700), (0,0,0), 1)
        cv2.line(mapImage, (800,100), (800,700), (0,0,0), 1)
        cv2.line(mapImage, (900,100), (900,700), (0,0,0), 1)
        x_1, y_1 = worldCoorToImageCoor(robot_1_PosX+450, robot_1_PosY+300)
        x_2, y_2 = worldCoorToImageCoor(robot_2_PosX+450, robot_2_PosY+300)
        x_3, y_3 = worldCoorToImageCoor(robot_3_PosX+450, robot_3_PosY+300)
        x_4, y_4 = worldCoorToImageCoor(robot_4_PosX+450, robot_4_PosY+300)         
        x_5, y_5 = worldCoorToImageCoor(robot_5_PosX+450, robot_5_PosY+300)
        ball_coor_x, ball_coor_y = (ball_x+450, ball_y+300)
        print("Ball X = ",ball_x, "Ball_Y", ball_y)

        

    ########################## STATUS STRATEGI ROBOT 1 ##########################       
        robot_1_text = "R1 Play :"
        robot_1_condition = play_1

        if robot_1_condition == False:
            robot_1_status = "False"
        elif robot_1_condition == True:
            robot_1_status = "True"
        else:
            robot_1_status = "BINGUNG"

    ########################## STATUS ROBOT 2 ##########################       
        robot_2_text = "R2 Play :"
        robot_2_condition = play_2

        if robot_2_condition == False:
            robot_2_status = "False"
        elif robot_2_condition == True:
            robot_2_status = "True"
        else:
            robot_2_status = "BINGUNG"

    ########################## STATUS ROBOT 3 ##########################       
        robot_3_text = "R3 Play :"
        robot_3_condition = play_3

        if robot_3_condition == False:
            robot_3_status = "False"
        elif robot_3_condition == True:
            robot_3_status = "True"
        else:
            robot_3_status = "BINGUNG"


    ########################## STATUS ROBOT 4 ##########################       
        robot_4_text = "R4 Play :"
        robot_4_condition = play_4

        if robot_4_condition == False:
            robot_4_status = "False"
        elif robot_4_condition == True:
            robot_4_status = "True"
        else:
            robot_4_status = "BINGUNG"
    # ########################## STATUS ROBOT 5 ##########################       
    #     robot_5_text = "ROBOT 5 :"
    #     robot_5_condition = robot_5_strategy

    #     if robot_5_condition == 0:
    #         robot_5_status = "GK"
    #     elif robot_5_condition == 1:
    #         robot_5_status = "ATTACK"
    #     elif robot_5_condition == 2:
    #         robot_5_status = "DEF.R"
    #     elif robot_5_condition == 3:
    #         robot_5_status = "DEF.L"
    #     else:
    #         robot_5_status = "BINGUNG"

    ########################## STATUS STRATEGI ROBOT 1 ##########################       
        robot_1_text_pickup = "R1 Pickup :"
        robot_1_condition_pickup = pickup_1

        if robot_1_condition_pickup == False:
            robot_1_status_pickup = "False"
        elif robot_1_condition_pickup == True:
            robot_1_status_pickup = "True"
        else:
            robot_1_status_pickup = "BINGUNG"

    ########################## STATUS ROBOT 2 ##########################       
        robot_2_text_pickup = "R2 Pickup :"
        robot_2_condition_pickup = pickup_2

        if robot_2_condition_pickup == False:
            robot_2_status_pickup = "False"
        elif robot_2_condition_pickup == True:
            robot_2_status_pickup = "True"
        else:
            robot_2_status_pickup = "BINGUNG"

    ########################## STATUS ROBOT 3 ##########################       
        robot_3_text_pickup = "R3 Pickup :"
        robot_3_condition_pickup = pickup_3

        if robot_3_condition_pickup == False:
            robot_3_status_pickup = "False"
        elif robot_3_condition_pickup == True:
            robot_3_status_pickup = "True"
        else:
            robot_3_status_pickup = "BINGUNG"


    ########################## STATUS ROBOT 4 ##########################       
        robot_4_text_pickup = "R4 Pickup :"
        robot_4_condition_pickup = pickup_4

        if robot_4_condition_pickup == False:
            robot_4_status_pickup = "False"
        elif robot_4_condition_pickup == True:
            robot_4_status_pickup = "True"
        else:
            robot_4_status_pickup = "BINGUNG"

    #########################################  Strategy GAN  ###############################

    ########################## STATUS STRATEGI ROBOT 1 ##########################       
        robot_1_text_yaw = "R1 YAW :"
        robot_1_status_yaw = str(yaw_1)
    ########################## STATUS ROBOT 2 ##########################       
        robot_2_text_yaw = "R2 YAW :"
        robot_2_status_yaw = str(yaw_2)

    ########################## STATUS ROBOT 3 ##########################       
        robot_3_text_yaw = "R3 YAW :"
        robot_3_status_yaw = str(yaw_3)

    ########################## STATUS ROBOT 4 ##########################       
        robot_4_text_yaw = "R4 YAW :"
        robot_4_status_yaw = str(yaw_4)

     #########################################  Strategy GAN  ###############################

    ########################## STATUS STRATEGI ROBOT 1 ##########################       
        robot_1_text_strategy = "Strategy R1 :"
        robot_1_status_strategy = str(strategy_1)
    ########################## STATUS ROBOT 2 ##########################       
        robot_2_text_strategy = "Strategy R2 :"
        robot_2_status_strategy = str(strategy_2)

    ########################## STATUS ROBOT 3 ##########################       
        robot_3_text_strategy = "Strategy R3 :"
        robot_3_status_strategy = str(strategy_3)

    ########################## STATUS ROBOT 4 ##########################       
        robot_4_text_strategy = "Strategy R4 :"
        robot_4_status_strategy = str(strategy_4)

        #########################################  Role GAN  ###############################

    ########################## STATUS STRATEGI ROBOT 1 ##########################       
        robot_1_text_role = "Role R1 :"
        robot_1_status_role = str(role_1)
    ########################## STATUS ROBOT 2 ##########################       
        robot_2_text_role = "Role R2 :"
        robot_2_status_role = str(role_2)

    ########################## STATUS ROBOT 3 ##########################       
        robot_3_text_role = "Role R3 :"
        robot_3_status_role = str(role_3)

    ########################## STATUS ROBOT 4 ##########################       
        robot_4_text_role = "Role R4 :"
        robot_4_status_role = str(role_4)
    ########################### DARI SINI JANGAN DISENTUH/DIUBAH ##################################################
        font = cv2.FONT_HERSHEY_SIMPLEX
        fontScale = 0.35
        color = (0, 0, 0)
        thickness = 1
        robot_1_text_size = cv2.getTextSize(robot_1_text, font, fontScale, thickness)
        #robot_1_condition_size = cv2.getTextSize(robot_1_status, font, fontScale, thickness)
        
        robot_2_text_size = cv2.getTextSize(robot_2_text, font, fontScale, thickness)
        #robot_2_condition_size = cv2.getTextSize(robot_2_status, font, fontScale, thickness)

        robot_3_text_size = cv2.getTextSize(robot_3_text, font, fontScale, thickness)
        #robot_3_condition_size = cv2.getTextSize(robot_3_status, font, fontScale, thickness)

        robot_4_text_size = cv2.getTextSize(robot_4_text, font, fontScale, thickness)
        #robot_4_condition_size = cv2.getTextSize(robot_4_status, font, fontScale, thickness)

        # robot_5_text_size = cv2.getTextSize(robot_5_text, font, fontScale, thickness)
        # robot_5_condition_size = cv2.getTextSize(robot_5_status, font, fontScale, thickness)
        robot_1_x_text_coordinate = 10
        robot_1_y_text_coordinate = robot_1_text_size[0][1] + 10
        robot_1_x_condition = 125
        robot_1_y_condition = robot_1_text_size[0][1] + 10

        robot_2_x_text_coordinate = 220
        robot_2_y_text_coordinate = robot_2_text_size[0][1] + 10
        robot_2_x_condition = 335
        robot_2_y_condition = robot_2_text_size[0][1] + 10

        robot_3_x_text_coordinate = 220*2
        robot_3_y_text_coordinate = robot_3_text_size[0][1] + 10
        robot_3_x_condition = 275*2 + 5
        robot_3_y_condition = robot_3_text_size[0][1] + 10

        robot_4_x_text_coordinate = 220*3
        robot_4_y_text_coordinate = robot_4_text_size[0][1] + 10
        robot_4_x_condition = 775
        robot_4_y_condition = robot_4_text_size[0][1] + 10


        ########################### PICKUP ##################################################
        font = cv2.FONT_HERSHEY_SIMPLEX
        fontScale = 0.35
        color = (0, 0, 0)
        thickness = 1
        robot_1_text_size_pickup = cv2.getTextSize(robot_1_text_pickup, font, fontScale, thickness)
        #robot_1_condition_size = cv2.getTextSize(robot_1_status, font, fontScale, thickness)
        
        robot_2_text_size_pickup = cv2.getTextSize(robot_2_text_pickup, font, fontScale, thickness)
        #robot_2_condition_size = cv2.getTextSize(robot_2_status, font, fontScale, thickness)

        robot_3_text_size_pickup = cv2.getTextSize(robot_3_text_pickup, font, fontScale, thickness)
        #robot_3_condition_size = cv2.getTextSize(robot_3_status, font, fontScale, thickness)

        robot_4_text_size_pickup = cv2.getTextSize(robot_4_text_pickup, font, fontScale, thickness)
        #robot_4_condition_size = cv2.getTextSize(robot_4_status, font, fontScale, thickness)

        # robot_5_text_size = cv2.getTextSize(robot_5_text, font, fontScale, thickness)
        # robot_5_condition_size = cv2.getTextSize(robot_5_status, font, fontScale, thickness)
        robot_1_x_text_coordinate_pickup = 10
        robot_1_y_text_coordinate_pickup = robot_1_text_size_pickup[0][1] + 25
        robot_1_x_condition_pickup = 125
        robot_1_y_condition_pickup = robot_1_text_size_pickup[0][1] + 25

        robot_2_x_text_coordinate_pickup = 220
        robot_2_y_text_coordinate_pickup = robot_2_text_size_pickup[0][1] + 25
        robot_2_x_condition_pickup = 335
        robot_2_y_condition_pickup = robot_2_text_size_pickup[0][1] + 25

        robot_3_x_text_coordinate_pickup = 220*2
        robot_3_y_text_coordinate_pickup = robot_3_text_size_pickup[0][1] + 25
        robot_3_x_condition_pickup = 275*2 + 5
        robot_3_y_condition_pickup = robot_3_text_size_pickup[0][1] + 25

        robot_4_x_text_coordinate_pickup = 220*3
        robot_4_y_text_coordinate_pickup = robot_4_text_size_pickup[0][1] + 25
        robot_4_x_condition_pickup = 775
        robot_4_y_condition_pickup = robot_4_text_size_pickup[0][1] + 25

        # robot_5_x_text_coordinate = 220*4
        # robot_5_y_text_coordinate = robot_5_text_size[0][1] + 10
        # robot_5_x_condition = 995
        # robot_5_y_condition = robot_5_text_size[0][1] + 10
        # cv2.circle(mapImage, (x_1 + 100, y_1 + 100), 3, (0, 0, 255), 5)
        # print("posisi robot 1 " + str(x_1) + " " + str(y_1))

        ########################### YAW ##################################################
        font = cv2.FONT_HERSHEY_SIMPLEX
        fontScale = 0.35
        color = (0, 0, 0)
        thickness = 1
        robot_1_text_size_yaw = cv2.getTextSize(robot_1_text_yaw, font, fontScale, thickness)
        #robot_1_condition_size = cv2.getTextSize(robot_1_status, font, fontScale, thickness)
        
        robot_2_text_size_yaw = cv2.getTextSize(robot_2_text_yaw, font, fontScale, thickness)
        #robot_2_condition_size = cv2.getTextSize(robot_2_status, font, fontScale, thickness)

        robot_3_text_size_yaw = cv2.getTextSize(robot_3_text_yaw, font, fontScale, thickness)
        #robot_3_condition_size = cv2.getTextSize(robot_3_status, font, fontScale, thickness)

        robot_4_text_size_yaw = cv2.getTextSize(robot_4_text_yaw, font, fontScale, thickness)
        #robot_4_condition_size = cv2.getTextSize(robot_4_status, font, fontScale, thickness)

        # robot_5_text_size = cv2.getTextSize(robot_5_text, font, fontScale, thickness)
        # robot_5_condition_size = cv2.getTextSize(robot_5_status, font, fontScale, thickness)
        robot_1_x_text_coordinate_yaw = 10
        robot_1_y_text_coordinate_yaw = robot_1_text_size_yaw[0][1] + 40
        robot_1_x_condition_yaw = 125
        robot_1_y_condition_yaw = robot_1_text_size_yaw[0][1] + 40

        robot_2_x_text_coordinate_yaw = 220
        robot_2_y_text_coordinate_yaw = robot_2_text_size_yaw[0][1] + 40
        robot_2_x_condition_yaw = 335
        robot_2_y_condition_yaw = robot_2_text_size_yaw[0][1] + 40

        robot_3_x_text_coordinate_yaw = 220*2
        robot_3_y_text_coordinate_yaw = robot_3_text_size_yaw[0][1] + 40
        robot_3_x_condition_yaw = 275*2 + 5
        robot_3_y_condition_yaw = robot_3_text_size_yaw[0][1] + 40

        robot_4_x_text_coordinate_yaw = 220*3
        robot_4_y_text_coordinate_yaw = robot_4_text_size_yaw[0][1] + 40
        robot_4_x_condition_yaw = 775
        robot_4_y_condition_yaw = robot_4_text_size_yaw[0][1] + 40


        ########################### Strategy ##################################################
        font = cv2.FONT_HERSHEY_SIMPLEX
        fontScale = 0.35
        color = (0, 0, 0)
        thickness = 1
        robot_1_text_size_strategy = cv2.getTextSize(robot_1_text_strategy, font, fontScale, thickness)
        #robot_1_condition_size = cv2.getTextSize(robot_1_status, font, fontScale, thickness)
        
        robot_2_text_size_strategy = cv2.getTextSize(robot_2_text_strategy, font, fontScale, thickness)
        #robot_2_condition_size = cv2.getTextSize(robot_2_status, font, fontScale, thickness)

        robot_3_text_size_strategy = cv2.getTextSize(robot_3_text_strategy, font, fontScale, thickness)
        #robot_3_condition_size = cv2.getTextSize(robot_3_status, font, fontScale, thickness)

        robot_4_text_size_strategy = cv2.getTextSize(robot_4_text_strategy, font, fontScale, thickness)
        #robot_4_condition_size = cv2.getTextSize(robot_4_status, font, fontScale, thickness)

        # robot_5_text_size = cv2.getTextSize(robot_5_text, font, fontScale, thickness)
        # robot_5_condition_size = cv2.getTextSize(robot_5_status, font, fontScale, thickness)
        robot_1_x_text_coordinate_strategy = 10
        robot_1_y_text_coordinate_strategy = robot_1_text_size_strategy[0][1] + 55
        robot_1_x_condition_strategy = 125
        robot_1_y_condition_strategy = robot_1_text_size_strategy[0][1] + 55

        robot_2_x_text_coordinate_strategy = 220
        robot_2_y_text_coordinate_strategy = robot_2_text_size_strategy[0][1] + 55
        robot_2_x_condition_strategy = 335
        robot_2_y_condition_strategy = robot_2_text_size_strategy[0][1] + 55

        robot_3_x_text_coordinate_strategy = 220*2
        robot_3_y_text_coordinate_strategy = robot_3_text_size_strategy[0][1] + 55
        robot_3_x_condition_strategy = 275*2 + 5
        robot_3_y_condition_strategy = robot_3_text_size_strategy[0][1] + 55

        robot_4_x_text_coordinate_strategy = 220*3
        robot_4_y_text_coordinate_strategy = robot_4_text_size_strategy[0][1] + 55
        robot_4_x_condition_strategy = 775
        robot_4_y_condition_strategy = robot_4_text_size_strategy[0][1] + 55


         ########################### Role ##################################################
        font = cv2.FONT_HERSHEY_SIMPLEX
        fontScale = 0.35
        color = (0, 0, 0)
        thickness = 1
        robot_1_text_size_role = cv2.getTextSize(robot_1_text_role, font, fontScale, thickness)
        #robot_1_condition_size = cv2.getTextSize(robot_1_status, font, fontScale, thickness)
        
        robot_2_text_size_role = cv2.getTextSize(robot_2_text_role, font, fontScale, thickness)
        #robot_2_condition_size = cv2.getTextSize(robot_2_status, font, fontScale, thickness)

        robot_3_text_size_role = cv2.getTextSize(robot_3_text_role, font, fontScale, thickness)
        #robot_3_condition_size = cv2.getTextSize(robot_3_status, font, fontScale, thickness)

        robot_4_text_size_role = cv2.getTextSize(robot_4_text_role, font, fontScale, thickness)
        #robot_4_condition_size = cv2.getTextSize(robot_4_status, font, fontScale, thickness)

        # robot_5_text_size = cv2.getTextSize(robot_5_text, font, fontScale, thickness)
        # robot_5_condition_size = cv2.getTextSize(robot_5_status, font, fontScale, thickness)
        robot_1_x_text_coordinate_role = 10
        robot_1_y_text_coordinate_role = robot_1_text_size_role[0][1] + 70
        robot_1_x_condition_role = 125
        robot_1_y_condition_role = robot_1_text_size_role[0][1] + 70

        robot_2_x_text_coordinate_role = 220
        robot_2_y_text_coordinate_role = robot_2_text_size_role[0][1] + 70
        robot_2_x_condition_role = 335
        robot_2_y_condition_role = robot_2_text_size_role[0][1] + 70

        robot_3_x_text_coordinate_role = 220*2
        robot_3_y_text_coordinate_role = robot_3_text_size_role[0][1] + 70
        robot_3_x_condition_role = 275*2 + 5
        robot_3_y_condition_role = robot_3_text_size_role[0][1] + 70

        robot_4_x_text_coordinate_role = 220*3
        robot_4_y_text_coordinate_role = robot_4_text_size_role[0][1] + 70
        robot_4_x_condition_role = 775
        robot_4_y_condition_role = robot_4_text_size_role[0][1] + 70
        # cv2.circle(mapImage, (x_2 + 100, y_2 + 100), 3, (0, 255, 255), 5)
        # print("posisi robot 2 " + str(x_2) + " " + str(y_2))

        cv2.circle(mapImage, (x_3 + 100, y_3 + 100), 3, (0, 0, 255), 10)
        print("posisi robot 3 " + str(x_3) + " " + str(y_3))

        # cv2.circle(mapImage, (x_4 + 100, y_4 + 100), 3, (0,0,0), 5)
        # print("posisi robot 4 " + str(x_4) + " " + str(y_4))

        #cv2.circle(mapImage, (x_5 + 100, y_5 + 100), 3, (175,175,175), 5)
        # print("posisi robot 5 " + str(x_5) + " " + str(y_5))
        
        # font = cv2.FONT_HERSHEY_SIMPLEX

        # cv2.putText(mapImage, '1', (x_1 + 100, y_1 + 100), font, 0.6, (0, 0, 255), 2, cv2.LINE_AA)
        # print("posisi robot 1 " + str(x_1) + " " + str(y_1))

        # cv2.putText(mapImage, '2', (x_2 + 100, y_2 + 100), font, 0.6, (0, 255, 255), 2, cv2.LINE_AA)
        # print("posisi robot 2 " + str(x_2) + " " + str(y_2))

        # cv2.putText(mapImage, '3', (x_3 + 100, y_3 + 100), font, 0.6, (255, 0, 0), 2, cv2.LINE_AA)
        # print("posisi robot 3 " + str(x_3) + " " + str(y_3))

        # cv2.putText(mapImage, '4', (x_4 + 100, y_4 + 100), font, 0.6, (0, 0, 0), 2, cv2.LINE_AA)
        # print("posisi robot 4 " + str(x_4) + " " + str(y_4))

        # triangle_1 = np.array([(x_1, y_1), (x_1 - 10, y_1 + 20), (x_1 + 10, y_1 + 20)], np.int32).reshape((-1, 1, 2))
        # cv2.polylines(mapImage, [triangle_1], True, (0, 0, 255), 5)  # Red
        # print("posisi robot 1 " + str(x_1) + " " + str(y_1))

        # triangle_2 = np.array([(x_2, y_2), (x_2 - 10, y_2 + 20), (x_2 + 10, y_2 + 20)], np.int32).reshape((-1, 1, 2))
        # cv2.polylines(mapImage, [triangle_2], True, (0, 255, 255), 5)  # Yellow
        # print("posisi robot 2 " + str(x_2) + " " + str(y_2))

        # triangle_3 = np.array([(x_3, y_3), (x_3 - 10, y_3 + 20), (x_3 + 10, y_3 + 20)], np.int32).reshape((-1, 1, 2))
        # cv2.polylines(mapImage, [triangle_3], True, (255, 0, 0), 5)  # Blue
        # print("posisi robot 3 " + str(x_3) + " " + str(y_3))

        # triangle_4 = np.array([(x_4 + 100, y_4+100), (x_4 - 10, y_4 + 20), (x_4 + 10, y_4 + 20)], np.int32).reshape((-1, 1, 2))
        # cv2.polylines(mapImage, [triangle_4], True, (0, 0, 0), 5)  # Black
        # print("posisi robot 4 " + str(x_4) + " " + str(y_4))

        # if found_ball_1 != 999 or found_ball_2 != 999 or found_ball_3 != 999 or found_ball_4 != 999 :   #setting Bola
        #     print("FoundBall 1:",found_ball_1,"Found BALL 2:",found_ball_2)
        #     cv2.circle(mapImage, (ball_coor_x + 100, ball_coor_y + 100), 3, (0,0,255), 10)
            
        cv2.putText(mapImage, robot_1_text, (robot_1_x_text_coordinate, robot_1_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_1_status, (robot_1_x_condition, robot_1_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_2_text, (robot_2_x_text_coordinate, robot_2_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_2_status, (robot_2_x_condition, robot_2_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_3_text, (robot_3_x_text_coordinate, robot_3_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_3_status, (robot_3_x_condition, robot_3_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_4_text, (robot_4_x_text_coordinate, robot_4_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_4_status, (robot_4_x_condition, robot_4_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

        # cv2.putText(mapImage, robot_5_text, (robot_5_x_text_coordinate, robot_5_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
        # cv2.putText(mapImage, robot_5_status, (robot_5_x_condition, robot_5_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)
    
        cv2.putText(mapImage, robot_1_text_pickup, (robot_1_x_text_coordinate_pickup, robot_1_y_text_coordinate_pickup), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_1_status_pickup, (robot_1_x_condition_pickup, robot_1_y_condition_pickup), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_2_text_pickup, (robot_2_x_text_coordinate_pickup, robot_2_y_text_coordinate_pickup), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_2_status_pickup, (robot_2_x_condition_pickup, robot_2_y_condition_pickup), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_3_text_pickup, (robot_3_x_text_coordinate_pickup, robot_3_y_text_coordinate_pickup), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_3_status_pickup, (robot_3_x_condition_pickup, robot_3_y_condition_pickup), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_4_text_pickup, (robot_4_x_text_coordinate_pickup, robot_4_y_text_coordinate_pickup), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_4_status_pickup, (robot_4_x_condition_pickup, robot_4_y_condition_pickup), font, fontScale, color, thickness, cv2.LINE_AA)


        cv2.putText(mapImage, robot_1_text_yaw, (robot_1_x_text_coordinate_yaw, robot_1_y_text_coordinate_yaw), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_1_status_yaw, (robot_1_x_condition_yaw, robot_1_y_condition_yaw), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_2_text_yaw, (robot_2_x_text_coordinate_yaw, robot_2_y_text_coordinate_yaw), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_2_status_yaw, (robot_2_x_condition_yaw, robot_2_y_condition_yaw), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_3_text_yaw, (robot_3_x_text_coordinate_yaw, robot_3_y_text_coordinate_yaw), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_3_status_yaw, (robot_3_x_condition_yaw, robot_3_y_condition_yaw), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_4_text_yaw, (robot_4_x_text_coordinate_yaw, robot_4_y_text_coordinate_yaw), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_4_status_yaw, (robot_4_x_condition_yaw, robot_4_y_condition_yaw), font, fontScale, color, thickness, cv2.LINE_AA)
    
        cv2.putText(mapImage, robot_1_text_strategy, (robot_1_x_text_coordinate_strategy, robot_1_y_text_coordinate_strategy), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_1_status_strategy, (robot_1_x_condition_strategy, robot_1_y_condition_strategy), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_2_text_strategy, (robot_2_x_text_coordinate_strategy, robot_2_y_text_coordinate_strategy), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_2_status_strategy, (robot_2_x_condition_strategy, robot_2_y_condition_strategy), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_3_text_strategy, (robot_3_x_text_coordinate_strategy, robot_3_y_text_coordinate_strategy), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_3_status_strategy, (robot_3_x_condition_strategy, robot_3_y_condition_strategy), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_4_text_strategy, (robot_4_x_text_coordinate_strategy, robot_4_y_text_coordinate_strategy), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_4_status_strategy, (robot_4_x_condition_strategy, robot_4_y_condition_strategy), font, fontScale, color, thickness, cv2.LINE_AA)



        cv2.putText(mapImage, robot_1_text_role, (robot_1_x_text_coordinate_role, robot_1_y_text_coordinate_role), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_1_status_role, (robot_1_x_condition_role, robot_1_y_condition_role), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_2_text_role, (robot_2_x_text_coordinate_role, robot_2_y_text_coordinate_role), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_2_status_role, (robot_2_x_condition_role, robot_2_y_condition_role), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_3_text_role, (robot_3_x_text_coordinate_role, robot_3_y_text_coordinate_role), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_3_status_role, (robot_3_x_condition_role, robot_3_y_condition_role), font, fontScale, color, thickness, cv2.LINE_AA)

        cv2.putText(mapImage, robot_4_text_role, (robot_4_x_text_coordinate_role, robot_4_y_text_coordinate_role), font, fontScale, color, thickness, cv2.LINE_AA)
        cv2.putText(mapImage, robot_4_status_role, (robot_4_x_condition_role, robot_4_y_condition_role), font, fontScale, color, thickness, cv2.LINE_AA)
    
    ############################################################### DIATAS JANGAN DISENTUH/DIUBAH #######################################################################

        smallMapImage = cv2.resize(mapImage, (1280,720), interpolation = cv2.INTER_AREA)
        cv2.imshow("Barelang Localization", smallMapImage)
        # cv2.waitKey(1)
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break

      
            

            
            

            
        
        

        # print("Sudah Diluar\n")
        # ball_x = data['d']
        # ball_y = data['z']

        # print(f"ball_x: {ball_x}")
        # print(f"ball_y: {ball_y}")

        
     

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt: 
        cv2.destroyAllWindows()




# import cv2
# import numpy as np
# import zmq
# import json

# robot_1_PosX, robot_1_PosY = 0,  0
# robot_2_PosX, robot_2_PosY = 0,  0
# robot_3_PosX, robot_3_PosY = 0,  0
# robot_4_PosX, robot_4_PosY = 0,  0
# robot_5_PosX, robot_5_PosY = 0,  0
# robot_1_strategy = 0
# robot_2_strategy = 0
# robot_3_strategy = 0
# robot_4_strategy = 0
# robot_5_strategy = 0
# # Define your own robot positions and strategies
# ball_x, ball_y = 0,0
# mapImage = np.zeros((800,1100,3), np.uint8)
# robotInitialPosition = np.zeros((3))
# context = zmq.Context()

# # Socket to talk to server
# print("Connecting to hello world server…")
# socket = context.socket(zmq.REQ)
# socket.connect("tcp://192.168.1.103:5555")
# # socket1 = context.socket(zmq.REQ)
# # socket1.connect("tcp://127.0.0.1:5556")
# # Your worldCoorToImageCoor function
# def worldCoorToImageCoor(x, y):		
#     x = x				
#     y = y		
#     return int(x), int(y)

# def main():
#     global robot_1_PosX, robot_1_PosY
#     global robot_2_PosX, robot_2_PosY
#     global robot_3_PosX, robot_3_PosY
#     global robot_4_PosX, robot_4_PosY
#     global robot_5_PosX, robot_5_PosY
#     global robot_1_strategy, robot_2_strategy, robot_3_strategy, robot_4_strategy, robot_5_strategy
#     global ball_x, ball_y
#     # global socket11, socket22
#     # context = zmq.Context()

#     # # Define the socket using the "Context"
#     # socket1 = context.socket(zmq.REQ)
#     # socket2 = context.socket(zmq.REQ)
#     # socket3 = context.socket(zmq.REQ)
#     # socket4 = context.socket(zmq.REQ)

#     # # Define the address for each socket
#     # socket1.connect("tcp://127.0.0.1:5555")
#     # socket2.connect("tcp://127.0.0.2:5556")
#     # socket3.connect("tcp://127.0.0.3:5557")
#     # socket4.connect("tcp://127.0.0.4:5558")

    
   
#     while True:
#         # update each robot's information
#         # socket1.send_string("request")
#         # reply1 = socket1.recv_string()
#         # data1 = json.loads(reply1)
#         # robot_1_PosX = data1['a']
#         # robot_1_PosY = data1['b']
#         # robot_1_strategy = data1['c']
        

#         # socket2.send_string("request")
#         # reply2 = socket2.recv_string()
#         # data2 = json.loads(reply2)
#         # robot_2_PosX = data2['a']
#         # robot_2_PosY = data2['b']
#         # robot_2_strategy = data2['c']

#         # socket3.send_string("request")
#         # reply3 = socket3.recv_string()
#         # data3 = json.loads(reply3)
#         # robot_3_PosX = data3['a']
#         # robot_3_PosY = data3['b']
#         # robot_3_strategy = data3['c']

#         # socket4.send_string("request")
#         # reply4 = socket4.recv_string()
#         # data4 = json.loads(reply4)
#         # robot_4_PosX = data4['a']
#         # robot_4_PosY = data4['b']
#         # robot_4_strategy = data4['c']

#         # print("Robot 1 position: ", robot_1_PosX, robot_1_PosY, " Strategy: ", robot_1_strategy)
#         # print("Robot 2 position: ", robot_2_PosX, robot_2_PosY, " Strategy: ", robot_2_strategy)
#         # print("Robot 3 position: ", robot_3_PosX, robot_3_PosY, " Strategy: ", robot_3_strategy)
#         # print("Robot 4 position: ", robot_4_PosX, robot_4_PosY, " Strategy: ", robot_4_strategy)
#         socket.send_string("Request")
#         message = socket.recv_string()
#         # Deserialize the data
#         data = json.loads(message)
#         robot_1_PosX = data['a']
#         robot_1_PosY = data['b']
#         # robot_1_strategy = data['c']
#         # ball_x = data['d']
#         # ball_y = data['z']
#         # Print the data
#         print("Received Robot 1: ", data)

#         # socket1.send_string("Request")
#         # message1 = socket1.recv_string()
#         # # Deserialize the data
#         # data1 = json.loads(message1)
#         # robot_2_PosX = data1['a']
#         # robot_2_PosY = data1['b']
#         # robot_2_strategy = data1['c']
        
#         # # Print the data
#         # print("Received Robot 2: ", data1)
            
#         mapImage[:] = (0, 255, 0)
#         cv2.rectangle(mapImage, (100,100), (1000,700), (255,255,255), 3) #. Garis Luar
#         cv2.rectangle(mapImage, (40,530), (100,270),(255,255,255), 3) # Garis Luar Gawang Kiri
#         cv2.rectangle(mapImage, (1000,530), (1060,270), (255,255,255), 3) # Garis Luar Gawang Kiri
#         cv2.rectangle(mapImage, (100,650), (200,150), (255,255,255), 3) # Garis Luar Gawang Kiri
#         cv2.rectangle(mapImage, (900,650), (1000,150), (255,255,255), 3) # Garis Luar Gawang Kiri
#         cv2.line(mapImage, (550,100), (550,700), (255,255,255), 3) # Garis Tengah
#         cv2.circle(mapImage, (550,400), 75, (255,255,255), 3) # Lingkaran Tengah
#         cv2.circle(mapImage, (250,400), 3, (255,255,255), 5)
#         cv2.circle(mapImage, (850,400), 3, (255,255,255), 5)
#         cv2.line(mapImage, (100,200), (1000,200), (0,0,0), 1)
#         cv2.line(mapImage, (100,300), (1000,300), (0,0,0), 1)
#         cv2.line(mapImage, (100,400), (1000,400), (0,0,0), 1)
#         cv2.line(mapImage, (100,500), (1000,500), (0,0,0), 1)
#         cv2.line(mapImage, (100,600), (1000,600), (0,0,0), 1)
                            
#         cv2.line(mapImage, (200,100), (200,700), (0,0,0), 1)
#         cv2.line(mapImage, (300,100), (300,700), (0,0,0), 1)
#         cv2.line(mapImage, (400,100), (400,700), (0,0,0), 1)
#         cv2.line(mapImage, (500,100), (500,700), (0,0,0), 1)
#         cv2.line(mapImage, (600,100), (600,700), (0,0,0), 1)
#         cv2.line(mapImage, (700,100), (700,700), (0,0,0), 1)
#         cv2.line(mapImage, (800,100), (800,700), (0,0,0), 1)
#         cv2.line(mapImage, (900,100), (900,700), (0,0,0), 1)
#         x_1, y_1 = worldCoorToImageCoor(robot_1_PosX+450, robot_1_PosY+300)
#         x_2, y_2 = worldCoorToImageCoor(robot_2_PosX+450, robot_2_PosY+300)
#         x_3, y_3 = worldCoorToImageCoor(robot_3_PosX+450, robot_3_PosY+300)
#         x_4, y_4 = worldCoorToImageCoor(robot_4_PosX+450, robot_4_PosY+300)         
#         x_5, y_5 = worldCoorToImageCoor(robot_5_PosX+450, robot_5_PosY+300)
#         ball_coor_x, ball_coor_y = (ball_x, ball_y)

        

#     ########################## STATUS STRATEGI ROBOT 1 ##########################       
#         robot_1_text = "ROBOT 1 :"
#         robot_1_condition = robot_1_strategy

#         if robot_1_condition == 0:
#             robot_1_status = "GK"
#         elif robot_1_condition == 1:
#             robot_1_status = "ATTACK"
#         elif robot_1_condition == 2:
#             robot_1_status = "DEF.R"
#         elif robot_1_condition == 3:
#             robot_1_status = "DEF.L"
#         else:
#             robot_1_status = "BINGUNG"

#     ########################## STATUS ROBOT 2 ##########################       
#         robot_2_text = "ROBOT 2 :"
#         robot_2_condition = robot_2_strategy

#         if robot_2_condition == 0:
#             robot_2_status = "GK"
#         elif robot_2_condition == 1:
#             robot_2_status = "ATTACK"
#         elif robot_2_condition == 2:
#             robot_2_status = "DEF.R"
#         elif robot_2_condition == 3:
#             robot_2_status = "DEF.L"
#         else:
#             robot_2_status = "BINGUNG"

#     ########################## STATUS ROBOT 3 ##########################       
#         robot_3_text = "ROBOT 3 :"
#         robot_3_condition = robot_3_strategy

#         if robot_3_condition == 0:
#             robot_3_status = "GK"
#         elif robot_3_condition == 1:
#             robot_3_status = "ATTACK"
#         elif robot_3_condition == 2:
#             robot_3_status = "DEF.R"
#         elif robot_3_condition == 3:
#             robot_3_status = "DEF.L"
#         else:
#             robot_3_status = "BINGUNG"

#     ########################## STATUS ROBOT 4 ##########################       
#         robot_4_text = "ROBOT 4 :"
#         robot_4_condition = robot_4_strategy

#         if robot_4_condition == 0:
#             robot_4_status = "GK"
#         elif robot_4_condition == 1:
#             robot_4_status = "ATTACK"
#         elif robot_4_condition == 2:
#             robot_4_status = "DEF.R"
#         elif robot_4_condition == 3:
#             robot_4_status = "DEF.L"
#         else:
#             robot_4_status = "BINGUNG"
#     ########################## STATUS ROBOT 5 ##########################       
#         robot_5_text = "ROBOT 5 :"
#         robot_5_condition = robot_5_strategy

#         if robot_5_condition == 0:
#             robot_5_status = "GK"
#         elif robot_5_condition == 1:
#             robot_5_status = "ATTACK"
#         elif robot_5_condition == 2:
#             robot_5_status = "DEF.R"
#         elif robot_5_condition == 3:
#             robot_5_status = "DEF.L"
#         else:
#             robot_5_status = "BINGUNG"


#     ########################### DARI SINI JANGAN DISENTUH/DIUBAH ##################################################
#         font = cv2.FONT_HERSHEY_SIMPLEX
#         fontScale = 0.65
#         color = (0, 0, 0)
#         thickness = 2
#         robot_1_text_size = cv2.getTextSize(robot_1_text, font, fontScale, thickness)
#         robot_1_condition_size = cv2.getTextSize(robot_1_status, font, fontScale, thickness)
        
#         robot_2_text_size = cv2.getTextSize(robot_2_text, font, fontScale, thickness)
#         robot_2_condition_size = cv2.getTextSize(robot_2_status, font, fontScale, thickness)

#         robot_3_text_size = cv2.getTextSize(robot_3_text, font, fontScale, thickness)
#         robot_3_condition_size = cv2.getTextSize(robot_3_status, font, fontScale, thickness)

#         robot_4_text_size = cv2.getTextSize(robot_4_text, font, fontScale, thickness)
#         robot_4_condition_size = cv2.getTextSize(robot_4_status, font, fontScale, thickness)

#         robot_5_text_size = cv2.getTextSize(robot_5_text, font, fontScale, thickness)
#         robot_5_condition_size = cv2.getTextSize(robot_5_status, font, fontScale, thickness)
#         robot_1_x_text_coordinate = 10
#         robot_1_y_text_coordinate = robot_1_text_size[0][1] + 10
#         robot_1_x_condition = 125
#         robot_1_y_condition = robot_1_text_size[0][1] + 10

#         robot_2_x_text_coordinate = 220
#         robot_2_y_text_coordinate = robot_2_text_size[0][1] + 10
#         robot_2_x_condition = 335
#         robot_2_y_condition = robot_2_text_size[0][1] + 10

#         robot_3_x_text_coordinate = 220*2
#         robot_3_y_text_coordinate = robot_3_text_size[0][1] + 10
#         robot_3_x_condition = 275*2 + 5
#         robot_3_y_condition = robot_3_text_size[0][1] + 10

#         robot_4_x_text_coordinate = 220*3
#         robot_4_y_text_coordinate = robot_4_text_size[0][1] + 10
#         robot_4_x_condition = 775
#         robot_4_y_condition = robot_4_text_size[0][1] + 10

#         robot_5_x_text_coordinate = 220*4
#         robot_5_y_text_coordinate = robot_5_text_size[0][1] + 10
#         robot_5_x_condition = 995
#         robot_5_y_condition = robot_5_text_size[0][1] + 10
#         cv2.circle(mapImage, (x_1 + 100, y_1 + 100), 3, (255,0,0), 5)
#         print("posisi robot 1 " + str(x_1) + " " + str(y_1))

#         # cv2.circle(mapImage, (x_2 + 100, y_2 + 100), 3, (55,55,55), 5)
#         # print("posisi robot 2 " + str(x_2) + " " + str(y_2))

#         #cv2.circle(mapImage, (x_3 + 100, y_3 + 100), 3, (100,100,100), 5)
#         # print("posisi robot 3 " + str(x_3) + " " + str(y_3))

#         # cv2.circle(mapImage, (x_4 + 100, y_4 + 100), 3, (125,125,125), 5)
#         # print("posisi robot 4 " + str(x_4) + " " + str(y_4))

#         #cv2.circle(mapImage, (x_5 + 100, y_5 + 100), 3, (175,175,175), 5)
#         # print("posisi robot 5 " + str(x_5) + " " + str(y_5))

#         #if ball_found == True: 
#         cv2.circle(mapImage, (ball_coor_x + 100, ball_coor_y + 100), 3, (0,0,255), 10)
            
#         cv2.putText(mapImage, robot_1_text, (robot_1_x_text_coordinate, robot_1_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
#         cv2.putText(mapImage, robot_1_status, (robot_1_x_condition, robot_1_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

#         cv2.putText(mapImage, robot_2_text, (robot_2_x_text_coordinate, robot_2_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
#         cv2.putText(mapImage, robot_2_status, (robot_2_x_condition, robot_2_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

#         cv2.putText(mapImage, robot_3_text, (robot_3_x_text_coordinate, robot_3_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
#         cv2.putText(mapImage, robot_3_status, (robot_3_x_condition, robot_3_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

#         cv2.putText(mapImage, robot_4_text, (robot_4_x_text_coordinate, robot_4_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
#         cv2.putText(mapImage, robot_4_status, (robot_4_x_condition, robot_4_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)

#         cv2.putText(mapImage, robot_5_text, (robot_5_x_text_coordinate, robot_5_y_text_coordinate), font, fontScale, color, thickness, cv2.LINE_AA)
#         cv2.putText(mapImage, robot_5_status, (robot_5_x_condition, robot_5_y_condition), font, fontScale, color, thickness, cv2.LINE_AA)
#     ############################################################### DIATAS JANGAN DISENTUH/DIUBAH #######################################################################

#         smallMapImage = cv2.resize(mapImage, (1280,720), interpolation = cv2.INTER_AREA)
#         cv2.imshow("Barelang Localization", smallMapImage)
#         # cv2.waitKey(1)
#         key = cv2.waitKey(1) & 0xFF
#         if key == ord('q'):
#             break

      
            

            
            

            
        
        

#         # print("Sudah Diluar\n")
#         # ball_x = data['d']
#         # ball_y = data['z']

#         # print(f"ball_x: {ball_x}")
#         # print(f"ball_y: {ball_y}")

        
     

# if __name__ == "__main__":
#     try:
#         main()
#     except KeyboardInterrupt: 
#         cv2.destroyAllWindows()

